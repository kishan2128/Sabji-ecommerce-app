# Vegetable E-commerce App
A simple vegetable store app built with React Native.